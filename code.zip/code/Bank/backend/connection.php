<?php

    $servername = "localhost";
    $username = "admin";
    $password = "bankentry";
    $db = "bank";

    $conn = mysqli_connect($servername,$username,$password,$db);

    if (!$conn) {
        die("Connection Error!");
    }





?>