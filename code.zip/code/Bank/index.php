<?php

require("backend/connection.php");

//Add the user details to the database
$add_visitor = "INSERT INTO `visitors_detail` (`user_ip`, `user_agent`) VALUES ('$_SERVER[REMOTE_ADDR]', '$_SERVER[HTTP_USER_AGENT]')";

mysqli_query($conn,$add_visitor);


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Welcome to HORIZON Bank</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.svg" rel="icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">
  
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NewBiz - v4.0.1
  * Template URL: https://bootstrapmade.com/newbiz-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <!-- Uncomment below if you prefer to use an text logo -->
         <h1><a href="index.php">HORIZON BANK</a></h1> 
        <!--<a href="index.php"><img src="./assets/img/favicon.png" alt="Logo" class="img-fluid"><b>&nbsp;&nbsp;SWIFT BANK</b></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
       
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- #header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="clearfix">
    <div class="container" data-aos="fade-up">

      <div class="hero-img" data-aos="zoom-out" data-aos-delay="200">
        <!-- <img src="assets/img/hero-img.svg" alt="" class="img-fluid"> -->
      </div>

      <div class="hero-info" data-aos="zoom-in" data-aos-delay="100">
        <h2>Welcome to the<br><span>HORIZON Bank</span><br>Services!</h2>
        <div>
          <a href="forms/employee-login.php" class="btn-get-started scrollto">Employee Login</a>
          <a href="forms/manager-login.php" class="btn-services scrollto">Manager Login</a>
        </div>
      </div>

    </div>
  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about">
      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h3>About Us</h3>
          <p>HORIZON is an Indian multinational is a public sector banking that provides financial services .</p>
        </header>

        <div class="row about-container">

          <div class="col-lg-6 content order-lg-1 order-2">
            <p>
              For HORIZON, Keeping pace with the transforming landscape of the Indian economy we have broadened our digital base in the recent years. 
            </p>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><i class="bi bi-card-checklist"></i></div>
              <h4 class="title"><a href="">Quick Start Account</a></h4>
              <p class="description">.</p>
            </div>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><i class="bi bi-brightness-high"></i></div>
              <h4 class="title"><a href="">Instant Fund Transfer</a></h4>
              <p class="description">.</p>
            </div>

            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><i class="bi bi-calendar4-week"></i></div>
              <h4 class="title"><a href="">safety at its best</a></h4>
              <p class="description">.</p>
            </div>

          </div>

          <div class="col-lg-6 background order-lg-2" data-aos="zoom-in">
            <!-- <img src="assets/img/about-img.svg" class="img-fluid" alt=""> -->
          </div>
        </div>



      </div>
    </section><!-- End About Section -->

    


        </div>

      </div>
    </section><!-- End Services Section -->

    
        <div class="row counters" data-aos="fade-up" data-aos-delay="100">

        <?php
            //Get the total number of visitors from database
            $get_visitors = "SELECT COUNT(id) AS visitors FROM visitors_detail";
            $visitor_result = mysqli_query($conn,$get_visitors);
            $visitor_data = mysqli_fetch_assoc($visitor_result);
        ?>
          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="<?php echo $visitor_data['visitors']; ?>" data-purecounter-duration="2" class="purecounter"></span>
            <p>Visitors</p>
          </div>

          <?php
            //Get the total number of employee from database
            $get_employee = "SELECT COUNT(ID) AS employee_num FROM employeedata";
            $employee_result = mysqli_query($conn,$get_employee);
            $employee_data = mysqli_fetch_assoc($employee_result);
        ?>
          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="<?php echo $employee_data['employee_num']; ?>" data-purecounter-duration="1" class="purecounter"></span>
            <p>Employees</p>
          </div>

          <?php
            //Get the total number of CUSTOMER from database
            $get_customer = "SELECT COUNT(ID) AS customer_num FROM customerdata";
            $customer_result = mysqli_query($conn,$get_customer);
            $customer_data = mysqli_fetch_assoc($customer_result);
        ?>
          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="<?php echo $customer_data['customer_num']; ?>" data-purecounter-duration="1" class="purecounter"></span>
            <p>Customers</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="42" data-purecounter-duration="1" class="purecounter"></span>
            <p>Hard Workers</p>
          </div>

        </div>

      </div>
    </section>

   


    <section id="contact">
      <div class="container-fluid" data-aos="fade-up">

        <div class="section-header">
          <h3>Contact Us</h3>
        </div>

        <div class="row">



          <div class="col-lg-6">
            <div class="row">
              <div class="col-md-5 info">
                <i class="bi bi-geo-alt"></i>
                <p>mount road,chennai</p>
              </div>
              <div class="col-md-4 info">
                <i class="bi bi-envelope"></i>
                <p>horizonsupport@yahoo.com</p>
              </div>
              <div class="col-md-3 info">
                <i class="bi bi-phone"></i>
                <p>9379739379</p>
              </div>
            </div>

            <!-----Contact form-->
            <div class="form">
              <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                <div class="row">
                  <div class="form-group col-lg-6">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                  </div>
                  <div class="form-group col-lg-6 mt-3 mt-lg-0">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                  </div>
                </div>
                <div class="form-group mt-3">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                </div>
                <div class="form-group mt-3">
                  <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
                </div>
                
                <div class="text-center"><button type="submit" name="contact_btn" title="Send Message">Send Message</button></div>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

        

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              56, AB complex<br>
              mount road<br>
              chennai<br>
              <strong>Phone:</strong> 93797393791<br>
              <strong>Email:</strong> horizonsupport@yahoo.com<br>
            </p>

           

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>For any query related to the bank, please feel free to contact us.</p>
            <form action="forms/subscribe.php" method="post">
              <input type="email" name="subsc_email"><input type="submit" name="subscribe_btn" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
       
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>